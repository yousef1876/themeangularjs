<!-- Listings Loader -->
<div class="listings-loader">
    <i class="fa fa-spinner fa-pulse"></i>
</div>
<ul class="resumes">