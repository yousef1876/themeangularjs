<?php

class Kirki_Customizer_Scripts extends Kirki_Customizer {

}
